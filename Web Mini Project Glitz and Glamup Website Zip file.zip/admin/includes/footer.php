<!--footer-->
    <div class="footer">
       <p>2020 &copy; Glitz and Glamup</p>
    </div>
        <!--//footer-->